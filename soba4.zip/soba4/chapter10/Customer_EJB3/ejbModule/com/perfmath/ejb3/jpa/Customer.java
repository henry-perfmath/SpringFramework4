package com.perfmath.ejb3.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the customer database table.
 * 
 */
@Entity
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	private String email;

	private boolean locked;

	private String name;

	private String password;

	//bi-directional many-to-one association to BankingTx
	@OneToMany(mappedBy="customer", fetch=FetchType.EAGER)
	private List<BankingTx> bankingTxs;

	public Customer() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean getLocked() {
		return this.locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<BankingTx> getBankingTxs() {
		return this.bankingTxs;
	}

	public void setBankingtxs(List<BankingTx> bankingTxs) {
		this.bankingTxs = bankingTxs;
	}

}