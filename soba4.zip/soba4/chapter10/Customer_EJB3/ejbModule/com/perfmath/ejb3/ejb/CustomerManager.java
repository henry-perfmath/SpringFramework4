package com.perfmath.ejb3.ejb;

import java.math.BigDecimal;
import java.util.List;

import com.perfmath.ejb3.jpa.Customer;
import com.perfmath.ejb3.jpa.BankingTx;

public interface CustomerManager {

	public void createCustomer(String name, String password, String email, boolean locked);
	public List<Customer> findAllCustomers();
	public Customer findCustomerByName(String name);
	public Customer findCustomerById(int id);
	
	public void saveTxs(int customerId, BigDecimal amount,
			String description, String type);
	public List<BankingTx> findAllTxs(int customerId);
}
