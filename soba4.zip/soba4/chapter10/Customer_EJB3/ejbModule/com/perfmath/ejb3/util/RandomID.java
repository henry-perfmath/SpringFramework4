package com.perfmath.ejb3.util;
import java.util.*;
public class RandomID {
int id;
public RandomID () {
	Random rand = new Random ();
	id = rand.nextInt(899999999);
}
public int getId() {
	return id;
}

}
