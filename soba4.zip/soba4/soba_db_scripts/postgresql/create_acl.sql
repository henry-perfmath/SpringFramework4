-- create PostgreSQL ACL tables

create table acl_sid (
    id bigserial primary key,
    principal boolean not null,
    sid varchar(100) not null
);
create unique index acl_sid_idx_1 on acl_sid (sid, principal);

create table acl_class (
    id bigserial primary key,
    class varchar(100) unique not null
) ;

create table acl_object_identity (
    id bigserial primary key,
    object_id_class bigint not null,
    object_id_identity bigint not null,
    parent_object bigint,
    owner_sid bigint,
    entries_inheriting boolean not null,
    foreign key (object_id_class) references acl_class (id),
    foreign key (parent_object) references acl_object_identity (id),
    foreign key (owner_sid) references acl_sid (id)
);

create unique index acl_object_identity_idx_1 on acl_object_identity (object_id_class, object_id_identity);

create table acl_entry (
    id bigserial primary key,
    acl_object_identity bigint not null,
    ace_order bigint not null,
    sid bigint not null,
    mask int not null,
    granting boolean not null,
    audit_success boolean not null,
    audit_failure boolean not null,
    foreign key (acl_object_identity)
        references acl_object_identity (id),
    foreign key (sid) references acl_sid (id)
);
create unique index acl_entry_idx_1 on acl_entry (acl_object_identity, ace_order);
