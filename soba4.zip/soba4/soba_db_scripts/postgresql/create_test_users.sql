INSERT INTO CUSTOMER (CUSTOMER_ID, FIRST_NAME, LAST_NAME, PHONE, ADDRESS, CITY, STATE, ZIPCODE, EMAIL, STATUS, CREATE_DATE) VALUES ('sobauser', 'sobauser', 
'sobauser', '9999999999', 'Any Way', 'Any City', 'CA', '99999', 'sobauser@xyz.com', 1, current_timestamp);

INSERT INTO CUSTOMER (CUSTOMER_ID, FIRST_NAME, LAST_NAME, PHONE, ADDRESS, CITY, STATE, ZIPCODE, EMAIL, STATUS, CREATE_DATE) VALUES ('sobarep', 'sobarep', 
'sobarep', '9999999998', 'Any Way', 'Any City', 'CA', '99999', 'sobarep@xyz.com', 1, current_timestamp);

INSERT INTO CUSTOMER (CUSTOMER_ID, FIRST_NAME, LAST_NAME, PHONE, ADDRESS, CITY, STATE, ZIPCODE, EMAIL, STATUS, CREATE_DATE) VALUES ('appadmin', 'appadmin', 
'appadmin', '9999999997', 'Any Way', 'Any City', 'CA', '99999', 'appadmin@xyz.com', 1, current_timestamp);

INSERT INTO LOGINUSER (USERNAME, PASSWORD, ENABLED, CREATE_DATE, CLOSE_DATE, CUSTOMER_ID) VALUES ('sobauser', 'sobauser', 1, current_timestamp, NULL, 'sobauser');
INSERT INTO LOGINUSER (USERNAME, PASSWORD, ENABLED, CREATE_DATE, CLOSE_DATE, CUSTOMER_ID) VALUES ('appadmin', 'appadmin', 1, current_timestamp, NULL, 'appadmin');
INSERT INTO LOGINUSER (USERNAME, PASSWORD, ENABLED, CREATE_DATE, CLOSE_DATE, CUSTOMER_ID) VALUES ('sobarep', 'sobarep', 1, current_timestamp, NULL, 'sobarep');

UPDATE AUTHORITIES SET AUTHORITY = 'ROLE_ADMIN' WHERE USERNAME= 'appadmin';
UPDATE AUTHORITIES SET AUTHORITY = 'ROLE_REP' WHERE USERNAME= 'sobarep';



