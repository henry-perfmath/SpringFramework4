CREATE FUNCTION random_string (length  INTEGER)
  RETURNS VARCHAR (500) AS $$
   DECLARE rdm_string VARCHAR (500);
  BEGIN
  rdm_string := substring (repeat(md5(rand()), 16) from 1 for length);
RETURN rdm_string;
 
END;
$$ LANGUAGE plpgsql;