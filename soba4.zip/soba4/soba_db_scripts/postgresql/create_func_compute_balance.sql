CREATE OR REPLACE FUNCTION compute_balance (acnt_id bigint, amount double precision)
  RETURNS double precision AS $$
  DECLARE
  curr_balance double precision;
  BEGIN
    SELECT balance into curr_balance FROM ACCOUNT
	WHERE account_id = acnt_id;
    RETURN (amount + curr_balance);
  END;
$$ LANGUAGE plpgsql;
  
