DROP SEQUENCE acl_sid_id_seq;
DROP SEQUENCE acl_class_id_seq;
DROP SEQUENCE aoi_id_seq;
DROP SEQUENCE ae_id_seq;

drop table acl_entry cascade constraints;
drop table acl_object_identity cascade constraints;
drop table acl_class cascade constraints;
drop table acl_sid cascade constraints;
