set linesize 200;
set pagesize 200;
column object_name format a30;
select OBJECT_TYPE, OBJECT_NAME FROM DBA_OBJECTS WHERE OWNER = 'SOBA31ADMIN' ORDER BY OBJECT_TYPE;