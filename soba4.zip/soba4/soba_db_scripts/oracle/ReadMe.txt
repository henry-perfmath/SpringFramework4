1) sqlplus system/system@ora11gr2 as sysdba
   >@create_soba_tablespaces.sql
   >@create_soba_schema_user.sql

2) sqlplus sobaadmin/sobaadmin@ora11gr2
   >@create_all.sql