CREATE USER sobaadmin identified by sobaadmin DEFAULT TABLESPACE OnlineBanking TEMPORARY TABLESPACE OBTemp;
GRANT CONNECT, RESOURCE to sobaadmin; 
GRANT SELECT ANY DICTIONARY to sobaadmin;
GRANT CREATE VIEW TO sobaadmin; 
GRANT CREATE SYNONYM TO sobaadmin; 
/
