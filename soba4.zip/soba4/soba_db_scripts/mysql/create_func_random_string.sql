DELIMITER //

CREATE FUNCTION random_string (length  INTEGER)
  RETURNS VARCHAR (500)
  
  BEGIN
 DECLARE rdm_string VARCHAR (500);
 
SET rdm_string = SUBSTRING(REPEAT(MD5(RAND()), 16) FROM 1 For length);
RETURN rdm_string;
 
 END//
  
DELIMITER ;