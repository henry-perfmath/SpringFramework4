package com.ejb2.test;

import java.util.*;
import javax.ejb.*;
import java.rmi.RemoteException;

public interface CustomerSession extends EJBObject {
	public int getTotalCustomers() throws FinderException, RemoteException;

	public void createCustomer(CustomerVO customer) throws CreateException,
			FinderException, RemoteException;

	public void changePassword(String name, String password)
			throws CustomerCredentialException, CustomerException,
			FinderException, RemoteException;

	public void changeEmail(String name, String email)
			throws CustomerCredentialException, CustomerException,
			FinderException, RemoteException;

	public boolean authenticateCustomer(String name, String password)
			throws CustomerCredentialException, FinderException, RemoteException;

	public boolean getLocked(String name)
			throws CustomerCredentialException, FinderException, RemoteException;

	public Collection getCustomers() throws FinderException, RemoteException;
	public CustomerVO getCustomerByID(String id) throws FinderException, RemoteException;

}
