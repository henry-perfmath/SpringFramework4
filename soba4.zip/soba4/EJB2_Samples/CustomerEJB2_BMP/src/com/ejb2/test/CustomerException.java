package com.ejb2.test;

public class CustomerException extends Exception {
	public CustomerException() {
	}

	public CustomerException(String msg) {
		super(msg);
	}
}
