package com.ejb2.test;

import java.util.Collection;
import javax.ejb.*;
import java.rmi.*;

public interface CustomerHome extends EJBHome
{
    public Customer create(String name, String password, String email, boolean locked) throws RemoteException, CreateException;
    public Customer findByPrimaryKey (String customerID) throws RemoteException, FinderException;
    public Customer findByCustomerName (String name) throws RemoteException, FinderException;
    public Collection findAll () throws RemoteException, FinderException;
    public int getTotalCustomers () throws RemoteException;
}
