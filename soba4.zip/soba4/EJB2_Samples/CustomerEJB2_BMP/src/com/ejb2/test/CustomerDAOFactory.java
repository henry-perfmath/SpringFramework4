package com.ejb2.test;
import javax.naming.*;
public class CustomerDAOFactory {
	public static CustomerDAO getDAO () throws CustomerDAOSysException {
		CustomerDAO customerDAO = null;
		String customerDAOClass = "java:comp/env/CustomerDAOClass";
		String className = null;
		try {
			InitialContext ic = new InitialContext ();
			className = (String) ic.lookup(customerDAOClass);
			customerDAO = (CustomerDAO) Class.forName(className).newInstance();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new CustomerDAOSysException (
					"CustomerDAOFactory.getDAO: " +
			"NamingException for <" + className +
			"> DAO class: \n" + ex.getMessage());
		}
		return customerDAO;
	}
}
