package com.ejb2.test;

import java.util.Collection;
import javax.ejb.*;

public interface CustomerLocalHome extends EJBLocalHome
{
    public CustomerLocal create(String name, String password, String email, boolean locked) throws CreateException;
    public CustomerLocal findByPrimaryKey (String customerID) throws FinderException;
    public Collection findByCustomerName (String name) throws FinderException;
    public Collection findAll () throws FinderException;
    public int getTotalCustomers () ;
}
