package com.ejb2.test;
import java.sql.*;

public class JDBCConnectionTestMySQL
{
    public static void main (String[] args)
    {
        Connection con = null;
        try
        {
            String userName = "admin";
            String password = "admin";
            String url = "jdbc:mysql://localhost:3306/ejb";
            Class.forName ("com.mysql.jdbc.Driver").newInstance ();
            con = DriverManager.getConnection (url, userName, password);
            System.out.println ("Database connection established: " +
            		con.getMetaData().toString());
            String insertStatement = "INSERT INTO customers (customerID, name, password, email, locked) VALUES " +
    				"( ?, ?, ?, ?, ?) ";
    		PreparedStatement prepStmt = null;
    		try {
    			prepStmt = con.prepareStatement(insertStatement);
    			prepStmt.setString(1, "100");
    			prepStmt.setString(2, "henry");
    			prepStmt.setString(3, "password");
    			prepStmt.setString(4, "henry@abc.com");
    			prepStmt.setBoolean(5, false);
    			prepStmt.executeUpdate();
    		} catch (SQLException ex) {
    			System.out.println (ex.getMessage());
    		} finally {
    			prepStmt.close();
    			con.close();
    		}	
        }
        catch (Exception e)
        {
            System.err.println ("Cannot connect to database server: " + e.getMessage());
        }
        finally
        {
            if (con != null)
            {
                try
                {
                    con.close ();
                    System.out.println ("Database connection terminated");
                }
                catch (Exception e) { /* ignore close errors */ }
            }
        }
    }
}
