package com.ejb2.test;

import java.util.*;

import javax.naming.*;
import javax.rmi.*;
import javax.ejb.*;

public class ejb2BMPDriver {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		System.out.println("testing Customer EJB2");
		InitialContext ctx = null;
		try {
			ctx = getInitialContext();
			String customerID = bmpTest(ctx);
			sessionTest(ctx, customerID);
		} catch (Exception ex) {
			System.out.println("Error in establishing initial context: "
					+ ex.getMessage());
		}
		long endTime = System.currentTimeMillis();
		System.out.println("total time: " + (endTime - startTime) / 1000.0
				+ " seconds");
	}

	public static String bmpTest(InitialContext ctx) {
		System.out
				.println("testing CustomerEJB2/BMP by calling the entity bean directly");
		long startTime = System.currentTimeMillis();
		String customerID = null;
		try {
			Object obj = ctx.lookup("Customer");

			CustomerHome home = (CustomerHome) PortableRemoteObject.narrow(obj,
					CustomerHome.class);

			String customerName = "c" + (new RandomID(10).getId());
			boolean locked = false;
			System.out.println("testing CustomerEJB2<BMP>: creating customer with name "
					+ customerName);

			Customer customer = home.create(customerName, "password",
					"customer0@abc.com", locked);
			customerID = customer.getCustomerID();
			System.out.println("customer with ID " + customerID + " created");
			Collection <Customer> customers = home.findAll();
			String primaryKey = null;
			System.out.println ("findAll found : " + customers.size() + " customers");
			Iterator<Customer> cust = customers.iterator();
			while (cust.hasNext ()) {
				Customer c = (Customer) cust.next();
				primaryKey = c.getCustomerID();
				System.out.println(c.getName() + ": "
						+ c.getPassword());
			}		
			System.out.println("testing CustomerEJB2: findByPrimaryKey");
			Customer findPK = home.findByPrimaryKey(primaryKey);
			findPK.setPassword("New Password");
			System.out.println("name = " + findPK.getName());

			System.out.println(home.getTotalCustomers()
					+ " customers in database.");

		} catch (CreateException ex) {
			System.err.println("Error creating customer: " + ex.getMessage());
		} catch (Exception ex) {
			System.err.println("Caught an unexpected exception: "
					+ ex.getMessage());
		}
		System.out.println("bmpTest execution time: "
				+ (System.currentTimeMillis() - startTime) / 1000.0
				+ " seconds");
		return customerID;
	}

	public static void sessionTest(InitialContext ctx, String customerID) {
		System.out.println("\nsesionBeanTest:");
		long startTime = System.currentTimeMillis();
		try {
			Object obj = ctx.lookup("CustomerSession");

			CustomerSessionHome home = (CustomerSessionHome) PortableRemoteObject
					.narrow(obj, CustomerSessionHome.class);
			String customerName = (new RandomID(10).getId());
			System.out.println("testing CustomerEJB2: creating customer_"
					+ customerName);

			CustomerVO customer = new CustomerVO(customerName, "password",
					"customer0@abc.com", false);
			CustomerSession customerSession = home.create();
			try {
				customerSession.createCustomer(customer);
			} catch (CreateException ex) {
				System.out.println("createCustomer error: " + ex.getMessage());
			}

			System.out.println("testing CustomerEJB2: getCustomers");
			Collection<CustomerVO> customers = customerSession.getCustomers();
			String name = null;
			String password = null;
			int count = 0;
			Iterator<CustomerVO> cust = customers.iterator();
			while (cust.hasNext()) {
				CustomerVO c0 = (CustomerVO) cust.next();
				if (count < 1) {
					name = c0.getName();
					password = c0.getPassword();
					count = 1;
					System.out.println(name + ": " + password);
				}
			}
			System.out.println("testing getCustomerByID:");
			try {
				CustomerVO customerVO = customerSession
						.getCustomerByID(customerID);
				System.out.println("getCustomerByID result: " + customerID);
			} catch (FinderException ex) {
				System.out
						.println("findByPrimaryKey error: " + ex.getMessage());
			}
			System.out.println("testing autheticateCustomer:");
			try {
				customerSession.authenticateCustomer(name, password);
				System.out.println("authenticating customer succeeded.");
			} catch (CustomerCredentialException ex) {
				System.out.println("authenticateCustomer error: "
						+ ex.getMessage());
			}

			System.out.println("testing getTotalCustomers:");
			int totalNumOfCustomers = customerSession.getTotalCustomers();
			System.out.println("total number of customers in database: "
					+ totalNumOfCustomers);

		} catch (CreateException ex) {
			System.err.println("Error creating object.");
			System.err.println(ex.getMessage());

		} catch (Exception ex) {
			System.err.println("Caught an unexpected exception.");
			System.err.println(ex.getMessage());
		}
		long endTime = System.currentTimeMillis();
		System.out.println("sessionTest execution time: "
				+ (endTime - startTime) / 1000.0 + " seconds");
	}

	protected static InitialContext getInitialContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("java.naming.factory.initial",
				"org.jboss.security.jndi.JndiLoginInitialContextFactory");
		env.put("java.naming.provider.url", "localhost:1099");
		env.put(Context.SECURITY_PRINCIPAL, "admin");
		env.put(Context.SECURITY_CREDENTIALS, "admin");
		return new InitialContext(env);
	}

}
