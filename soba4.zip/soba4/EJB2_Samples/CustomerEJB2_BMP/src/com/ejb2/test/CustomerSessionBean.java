package com.ejb2.test;

import java.util.*;
import javax.ejb.*;
import javax.naming.*;
public class CustomerSessionBean implements SessionBean {
	private CustomerLocalHome customerHome;
	public int getTotalCustomers () {
		return customerHome.getTotalCustomers();
	}
	public void createCustomer (CustomerVO customer)
	throws CreateException, FinderException {
		if (customer.getName() == null 
			|| customer.getPassword () == null
			|| customer.getEmail () == null) {
			throw new CreateException ("Customer data is null");
		}
		if (customer.getName() == "" 
				|| customer.getPassword () == ""
				|| customer.getEmail () == "") {
				throw new CreateException ("Customer fields cannot be empty");
			}
		Collection customers = customerHome.findByCustomerName (customer.getName ());
		if (customers.size() == 0) {
			customerHome.create (
					customer.getName () ,
					customer.getPassword (),
					customer.getEmail (),
					customer.getLocked());
		} else {
			throw new CreateException (
					"Customer name already in use.");
		}
	}
	public void changePassword (String name, String password)
			throws CustomerCredentialException, CustomerException, FinderException {
				if (password.equals("")) {
					throw new CustomerException ("Password cannot be empty");
				}
				Collection customers = customerHome.findByCustomerName (name);
				if (customers.size() == 1) {
					Iterator customer = customers.iterator();
					CustomerLocal cust = (CustomerLocal) customer.next ();
					cust.setPassword(password);
				} else {
					throw new CustomerCredentialException (
							"Cannot find customer " + name);
				}
			}
	public void changeEmail (String name, String email)
			throws CustomerCredentialException, CustomerException, FinderException {
				if (email.equals("")) {
					throw new CustomerException ("email cannot be empty");
				}
				Collection customers = customerHome.findByCustomerName (name);
				if (customers.size() == 1) {
					Iterator customer = customers.iterator();
					CustomerLocal cust = (CustomerLocal) customer.next ();
					cust.setEmail (email);
				} else {
					throw new CustomerCredentialException (
							"Cannot find customer " + name);
				}
			}
	public boolean authenticateCustomer (String name, String password)
			throws CustomerCredentialException, FinderException {
		boolean valid = false;
				Collection customers = customerHome.findByCustomerName (name);
				if (customers.size() == 1) {
					Iterator customer = customers.iterator();
					CustomerLocal cust = (CustomerLocal) customer.next ();
					if (!cust.getPassword().equals(password)) {
						throw new CustomerCredentialException (
								"Incorrect password for customer " + name);
					} else {
						valid = true;
					}
				} else {
					throw new CustomerCredentialException (
							"Cannot find customer " + name);
				}
				return valid;
			}
	public String findByPrimaryKey (String customerID)
			throws FinderException {
				CustomerLocal customer = customerHome.findByPrimaryKey (customerID);
				if (customer != null) {
					return customer.getCustomerID();
				} else {
					return "not found";
				}
			}
	public boolean getLocked (String name)
			throws CustomerCredentialException, FinderException {
				Collection customers = customerHome.findByCustomerName (name);
				if (customers.size() == 1) {
					Iterator customer = customers.iterator();
					CustomerLocal cust = (CustomerLocal) customer.next ();
					return cust.getLocked();
				} else {
					throw new CustomerCredentialException (
							"Cannot find customer " + name);
				}
			}
	public Collection getCustomers ()
			throws FinderException {
		ArrayList customerList = new ArrayList ();
				Collection customers = customerHome.findAll();
				Iterator all = customers.iterator();
				while (all.hasNext()) {
					CustomerLocal customerEJB = (CustomerLocal)all.next();
					CustomerVO customer = new CustomerVO (customerEJB.getName(),
							customerEJB.getPassword(),
							customerEJB.getEmail(),
							customerEJB.getLocked());
					customerList.add (customer);
				}
				return customerList;
			}
	public CustomerVO getCustomerByID (String id)
			throws FinderException {
				CustomerLocal  cust = customerHome.findByPrimaryKey(id);
				CustomerVO customerVO = new CustomerVO (cust.getName(),
						cust.getPassword(), cust.getEmail(), cust.getLocked());
				return customerVO;
			}
	public CustomerSessionBean () {}
	public void ejbCreate () {
		try {
			Context initial = new InitialContext ();
			Object objref = initial.lookup("java:comp/env/ejb/Customer");
			customerHome = (CustomerLocalHome) objref;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new EJBException (ex.getMessage());
		}
	}
	public void ejbRemove () {}
	public void ejbActivate () {}
	public void ejbPassivate () {}
	public void setSessionContext (SessionContext sc) {}
}
