package com.ejb2.test;

public class CustomerCredentialException extends Exception {
	public CustomerCredentialException() {
	}

	public CustomerCredentialException(String msg) {
		super(msg);
	}
}
