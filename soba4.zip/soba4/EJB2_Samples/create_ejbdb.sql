create database ejb;
grant usage on *.* to admin@localhost identified by 'admin';
grant all privileges on ejb.* to admin@localhost;
show databases;
 
