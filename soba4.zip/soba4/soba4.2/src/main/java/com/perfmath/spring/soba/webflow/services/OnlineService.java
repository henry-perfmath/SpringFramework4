package com.perfmath.spring.soba.webflow.services;

import java.util.List;

public interface OnlineService {

    public List<String> getServices();
}
