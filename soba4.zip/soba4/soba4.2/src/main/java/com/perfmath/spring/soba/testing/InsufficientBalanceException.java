package com.perfmath.spring.soba.testing;

public class InsufficientBalanceException extends RuntimeException {

}
